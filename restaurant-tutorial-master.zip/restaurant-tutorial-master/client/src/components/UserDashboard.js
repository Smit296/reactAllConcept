import React from 'react';

const UserDashboard = () => {
    return <div>Inside UserDashboard</div>;
};

export default UserDashboard;
